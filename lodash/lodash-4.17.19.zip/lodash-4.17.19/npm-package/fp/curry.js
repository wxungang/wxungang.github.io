var convert = require('./convert'),
    func = convert('curry', require('../curry'));

func.placeholder = require('./placeholder');
module.exports = func;
